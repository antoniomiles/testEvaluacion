package se.ff.bs.cliente;

public class ClienteInf {

    String name;
    String lastName;
    int clientId;

    public ClienteInf(String name, String lastName, int clientId) {
        this.name = name;
        this.lastName = lastName;
        this.clientId = clientId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }
}
