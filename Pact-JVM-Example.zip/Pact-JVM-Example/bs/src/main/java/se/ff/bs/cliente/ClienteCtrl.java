package se.ff.bs.cliente;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ClienteCtrl {

    @RequestMapping("/v1/client")
    public ClienteInf getClients(@RequestParam int id) {
        return getClientBy(id);
    }

    private ClienteInf getClientBy(int id) {
        ClienteInf clienteInf;
        switch (id) {
            case 0:
                clienteInf = new ClienteInf("Percy", "Mendoza", id);
                break;
            case 1:
                clienteInf = new ClienteInf("Juan", "Perez", id);
                break;
            case 2:
                clienteInf = new ClienteInf("Mari", "Rojas", id);
                break;
            default:
                clienteInf = new ClienteInf("NOT_DEFINED", "NOT_DEFINED", id);
        }
        return clienteInf;
    }

}
