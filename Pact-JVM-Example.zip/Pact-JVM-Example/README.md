# Pact-JVM-Example
Basic example of Consumer driven contract testing using Pact JVM (December 2017)

A video demonstrating the use of this example is here: 

https://www.youtube.com/watch?v=F-IUh0M-pu8

Commands used to execute upload of pact-file and doing pact verification on Provider side: 

mvn pact:publish

mvn pact:verify

Note: I don't clame to have a perfect understanding of Pact and Pact-JVM. This is more of a "note to self" and others who are just starting to learn what Pact-JVM is all about. Qusetions are welcome: mattiasmgn@gmail.com

This example might soon be out of date. This was created in December 2017. 

Links:

https://github.com/DiUS/pact_broker-docker

https://github.com/DiUS/pact-jvm/tree/master/pact-jvm-consumer-junit

https://github.com/DiUS/pact-jvm/tree/master/pact-jvm-provider-junit

https://github.com/DiUS/pact-jvm/tree/master/pact-jvm-provider-maven
