package se.ff.bsc;

import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRuleMk2;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.DslPart;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;
import org.junit.Rule;
import org.junit.Test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class FindClientByIdTest {

    @Rule
    public PactProviderRuleMk2 provider = new PactProviderRuleMk2("FindClientServiceV1", "localhost", 8112, this);

    /**
     * Se crea el pacto del Request y el Response
     */
    @Pact(consumer = "FindClientServiceV1Client")
    public RequestResponsePact createFindClientServicePact(PactDslWithProvider builder) {
        Map<String, String> header = new HashMap<>();
        header.put("Content-Type", "application/json");

        DslPart clientResult = new PactDslJsonBody()
                .stringType("name", "Juan")
                .stringType("lastName", "Perez")
                .integerType("clientId", 1);

        return builder
                .given("There is a client with id 1")
                .uponReceiving("A request with the id 1")
                .path("/v1/client")
                .method("GET")
                .query("id=1")
                .willRespondWith()
                .headers(header)
                .status(200)
                .body(clientResult)
                .toPact();
    }

    @Test
    @PactVerification()
    public void doTestOfPact() throws IOException {
        System.setProperty("pact.rootDir", "../pacts");  // Change output dir for generated pact-files
        String infoClient = new FindClientById(provider.getPort()).getClientById(1);
        System.out.println("The client info is: " + infoClient);
    }

}
