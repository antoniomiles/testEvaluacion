package se.ff.bsc;

import org.apache.http.HttpResponse;
import org.apache.http.client.fluent.Request;
import org.apache.http.util.EntityUtils;


import java.io.IOException;

public class FindClientById {

    int port = 8111;

    public FindClientById(int port) {
        this.port = port;
        System.out.println("Running by port: " + this.port);
    }

    public FindClientById() {
        System.out.println("Default port " + this.port);
    }

    public static void main(String[] args) throws IOException {
        FindClientById findClientId = new FindClientById();
        System.out.println("Cliente info: " + findClientId.getClientById(2));
    }

    public String getClientById(int clientId) throws IOException {
        HttpResponse respose = Request.Get("http://localhost:" + this.port + "/v1/client?id=" + clientId)
                .execute().returnResponse();
        return EntityUtils.toString(respose.getEntity());
    }

}
